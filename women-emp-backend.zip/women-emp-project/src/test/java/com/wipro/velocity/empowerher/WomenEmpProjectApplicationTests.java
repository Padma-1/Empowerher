package com.wipro.velocity.empowerher;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WomenEmpProjectApplicationTests 
{

	@Test
	void contextLoads() 
	{
		
	}
	
	@Test
	public void main() 
	{
		WomenEmpProjectApplication.main(new String[] {});
	}

}
