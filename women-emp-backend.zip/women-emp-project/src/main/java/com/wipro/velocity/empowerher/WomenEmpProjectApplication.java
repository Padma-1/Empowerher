package com.wipro.velocity.empowerher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WomenEmpProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(WomenEmpProjectApplication.class, args);
	}

}
